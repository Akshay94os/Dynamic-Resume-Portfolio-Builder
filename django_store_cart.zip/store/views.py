from django.shortcuts import render, redirect, get_object_or_404
from .models import Product

def product_list(request):
    if Product.objects.count() == 0:
        Product.objects.create(name="Mechanical Keyboard", price=89.99, stock=15)
        Product.objects.create(name="Wireless Gaming Mouse", price=49.99, stock=25)
        Product.objects.create(name="USB-C Monitor Hub", price=34.50, stock=30)
    
    products = Product.objects.all()
    cart = request.session.get('cart', {})
    cart_count = sum(cart.values())
    return render(request, 'store/index.html', {'products': products, 'cart_count': cart_count})

def add_to_cart(request, product_id):
    cart = request.session.get('cart', {})
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    request.session['cart'] = cart
    return redirect('product_list')

def view_cart(request):
    cart = request.session.get('cart', {})
    items = []
    total = 0
    for pid, qty in cart.items():
        prod = Product.objects.get(id=pid)
        subtotal = float(prod.price) * qty
        total += subtotal
        items.append({'product': prod, 'qty': qty, 'subtotal': subtotal})
    return render(request, 'store/cart.html', {'items': items, 'total': total})

def clear_cart(request):
    request.session['cart'] = {}
    return redirect('product_list')
