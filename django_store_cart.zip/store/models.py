from django.db import models

class Product(models.Model):
    name = models.CharField(max_length=120)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    stock = models.IntegerField(default=10)

    def __str__(self):
        return f"{self.name} - undefined"
